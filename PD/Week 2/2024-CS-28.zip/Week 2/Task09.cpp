#include <iostream>
using namespace std;
main() {
 cout<<"----------------------------------"<<endl;
 cout<<"                                  "<<endl;
 cout<<"      o    ^__^                   "<<endl;
 cout<<"       o   (oo)\\________         "<<endl;
 cout<<"                                  "<<endl;
 cout<<"           (__)\\       )\\/\\    "<<endl;
 cout<<"               ||----W |          "<<endl;
 cout<<"               ||     ||          "<<endl;
}